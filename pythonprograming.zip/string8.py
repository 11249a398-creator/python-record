a="python program"
print(a[0:8])
print(a[0:])
print(a[:12])
print(a[-1:-8])
print(a[-3:])
print(a[:-7])