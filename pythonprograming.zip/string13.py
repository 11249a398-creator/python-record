text = " Hello World!"
cleaned = text.strip()
print(cleaned)

text = "Hello world!"
updated = text.replace("world", "everyone")
print(updated)

