name="Talapanti Gokula Krishna Priya"
length=len(name)
print(length)
character='a'
position=name.find(character)
print(position)