text="python programing"
print("".join(text))
print(text.capitalize())
print(text.title())
print(text.replace("python","c"))
