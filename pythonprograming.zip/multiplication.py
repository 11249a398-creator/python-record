b=int(input("enter 1 number:"))
b1=int(input("enter 2 number:"))
b2=int(input("enter 3 number:"))
c=b+b1
d=b2*c
print("multiplication",d)