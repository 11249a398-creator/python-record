a=int(input("total bill:"))
b=int(input("number of diners:"))
c=a/b
print("division",c)