a=int(input("enter weight in kilograms:"))
b=a*2204
print("weight in pounds",b)