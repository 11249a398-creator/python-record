word = "Hello World"
print("The string is:",word)
character="H"
print("The character is:",character)
position=word.index(character)
print("The index of the character in the string is:",position)