text = "Hello World"
print(text.upper())
print(text.lower())