a=int(input("enter a number over 100:"))
b=int(input("enter a number below 10:"))
c=a/b
print("a goes in b",c)