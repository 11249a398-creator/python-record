tuple1=(1,'a',2,'b')
tuple2=(3,'c',4,'d')
print(type(tuple1))
print(len(tuple1))