f=open("demo.py",'a')
f.write("i am bts army\n")
f.write("i am fan of pond naravit")
f.close()
