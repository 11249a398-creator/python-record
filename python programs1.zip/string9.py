string = "Hello World"
print(''.join(reversed(string)))
