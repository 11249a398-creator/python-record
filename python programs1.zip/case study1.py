fruits=["apple","banana","cherry","pineapple","kiwi"]
newlist=[]
for x in fruits:
    if "a" in x:
        newlist.append(x)
        print(newlist)