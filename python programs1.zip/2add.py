a=int(input("enter 1 number:"))
b=int(input("enter 2 number:"))
c=a+b
print("add",c)