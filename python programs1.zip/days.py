a=int(input("number of days:"))
b=a*24
print("hours",b)
c=b*60
print("mintues",c)
d=c*60
print("seconds",d)