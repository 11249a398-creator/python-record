import random
num=random.random()
num=num*100
print(num)
num = random.randint(0,9)
print(num)
num1=random.randint(0,1000)
num2=random.randint(0,1000)
new_num=num1/num2
print(new_num,num1,num2)
num3=random.randrange(0,100,5)
print(num3)
colour=random.choice(["red","orange","purple"])
print(colour)