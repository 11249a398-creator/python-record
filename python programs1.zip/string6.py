s="123"
p="abc"
g="1a2"
print(s.isdigit())
print(p.isalpha())
print(g.isalnum())