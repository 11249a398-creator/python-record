n="hello world"
print(n)
letter=n[4]
print(letter)