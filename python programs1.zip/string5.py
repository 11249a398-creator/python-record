text="filename.txt"
print(text.startswith("file"))
print(text.endswith(".pdf"))
