a=input("what is your first name:")
a1=input("what is your surname:")
print("name",a,a1)