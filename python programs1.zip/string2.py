text="apple,orange,cherry"
print(text.split(","))