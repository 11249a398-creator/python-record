import random
num = random.randint(0,9)
print(num)
