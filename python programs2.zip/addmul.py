
a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))
c = float(input("Enter the third number: "))
answer = (a + b) * c
print("The answer is", answer)
