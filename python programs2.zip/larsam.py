num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
if num1 > num2:
    print(num2, num1)
else:
    print(num1, num2)
