a=int(input("enter the number over 100"))
b=int(input("enter the number under 10"))
c=a/b
print("large number goes in smaller number",c)
