total_slices = int(input("How many slices of pizza did you start with? "))
eaten_slices = int(input("How many slices have you eaten? "))
remaining_slices = total_slices - eaten_slices
print("You have", remaining_slices, "slices of pizza left.")
