celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9/5) + 32
print(celsius, "Celsius is equal to", fahrenheit, "Fahrenheit")
