total_bill = float(input("Enter the total price of the bill: "))
diners = int(input("Enter the number of diners: "))
each_pay = total_bill / diners
print("Each person must pay", each_pay)
