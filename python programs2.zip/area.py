radius = float(input("Enter the radius of the circle: "))
pi = 3.14159
area = pi * radius * radius
print("The area of the circle is:", area)
